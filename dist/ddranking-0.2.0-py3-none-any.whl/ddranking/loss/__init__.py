from .kl import KLDivergenceLoss
from .sce import SoftCrossEntropyLoss
from .mse_gt import MSEGTLoss